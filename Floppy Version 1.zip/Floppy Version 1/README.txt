Thank You For Purchasing Asbestosstar's Browser Floppy 1 Edition, Here I Will Cover What the browser does, How You Would Update It, and all other stuff.


This Is a Fork Of Asbestosstar's Web Browser Which is desgined to run on older computers and sell on Floppy Discs. We Plan to move the Origniall Asbestosstar's Browser to the Gecko Browser Runtime, while the floppy fork will stay on the
current runtime. The Current Runtime is of IE 7. It is reccomended that you have the latest Version of Internet Explorer on your computer for this browser to be at its best. This Browser is not Reccomended For Computers With Windows XP Service Pack 2 or Higher, for This We Will Reccomend our Main Fork.
The Reason For Keeping The Runtime for This Fork of That Of IE's is to Keep Low System Requirements.

The System Requirents For This Software are the  Same As For .NET 1.1.

The Web Browser Partially Uses Runtime From your Computers IE, so its bets to have then newest version.

.Net FrameWork 1.1 (Included ON CD)
Around 80 MegaBytes For .Net FrameWork
16-32 MegaBytes Reccomended in RAM (Though, not Many Modern Web Pages Will Run Well on THAT)
Windows NT 4.0 Service Pack 7/6A Or Windows 98 Or Higher
This Will not Work on Windows 95 Or 3.x or Below Without Modifycation
Internet Connection
Floppy Port(If You Bough This on a floppy Disc)
CD/DVD Drive(If YOu Bought THis on CD or Are Installing .NET from a CD)
Most DVD drives support CDs

THe Browser Veiws Web Pages And Performance depend on A little on OS


What Will You Get

You Will Get a 3.5 Inch Floppy Disc With The Browser On it, If You Want To Install it, just Copy The Folder inside, and then drop it in the Location you want it to be on.

A CD  with the .NET FRAMEWORK Installer And Windows Installer 1.1. The File was too large so we had to Give It on a CD.




How To Create A SHortCut On your Desktop?

For This, Right Click on Your Dextop, New Shortcut, Then Select The Location And Finish



What do the Buttons On The Browser Do?
The File Button Can Exit, The About Button Can Give You Information About What Verison you are on.

The Back Button Goes Back To The Previous Web Page
The Forward Button Goes to the Forward Page.
Stop Stops The Current Web Page From Loading.
Refresh Reloads the Page
The Search Button Searches The Big Bar For URL's
The Other Search Button is for searching DuckDuckGo.
The Buttons On The Side are ShortCuts To Web Pages Such As Asbestosstar.Com, Google, Duckduckgo, and More

The Stop JavaScript Errors Checkbox Stops Java Script Errors , Those Are The Yellow Popups

The HomePage Takes you to the Homepage You Set In Your Internet Options

How Can I update This Browser?
You Can Go to Asbestosstar.com and Get the latest Version
If You Do not Want to DO that, You can Get The Newest Version On Floppy Disc Or DVD Upgrade
Some Versions May not support Direct Upgrades, so you will have to buy a full.

If I can Just Download It Why Buy it?

The Reason We provide the floppy Disc Version is so if you have the Disc, or do not want to Download it from a Network, or The Browser You Using Has Problems Downloading. Plus If You Want to Make A small Donation to Me.

Prices
1$ Cents Shipping and Handling
Disc 1.50$
CD 20 cents
50 Cents For the Software
20 Cents Donation
Total: 3.40$

For Upgrade It is 20 Cents Less, Taking 20 Cents Out Of The Software.



Whats Your Refund Policy?

We DO not sadly offer Refunds as of Now (March 2018), maybe give it to a friend, he may want it.

Whats Your Damage and Liability Policy?

We Do not take damage for anything Bad That Happens to you or Your Computer From THis Product. If You Need Help, Call Email Me , I may be Able to help You.

Whats Your Redistributing Policy?

We ENCOURAGE the copying and Piracy and Redistributing of Most Of Our Software. It Helps Us Get People get to know our Brand and Helps Fan Made Updates if you Open THe Source Code. We Encourage You to reverse engineer Asbestosstar's Floppy Disc Editions.
It Helps. We Also like people modifying it. It Also Opens the Way to Extentions Which We Have Planned. We Just Encourage you to Also Reference Asbestosstar if you turn this into its own browser.

Similar to The Unlicense

How Can I contact you?

I prefer by EMAIL: Asbestosstar@asbestosstar.com


Thank You.


























